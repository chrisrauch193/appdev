package com.openfaceapp.cr217.facepredict;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    static final int REQUEST_IMAGE_CAPTURE = 1;
    String mCurrentPhotoPath;
    static final int REQUEST_TAKE_PHOTO = 1;

    static boolean learning = true;

    private RequestQueue queue;
    private static final String URL_SEND = "http://localhost:8080/";

    EditText newName;
    Button lButton;
    Button pButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newName = (EditText) findViewById(R.id.editText);
        lButton = (Button) findViewById(R.id.learnButton);
        pButton = (Button) findViewById(R.id.predictButton);
        queue = Volley.newRequestQueue(this);

        newName.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {

                if (newName.getText().toString().equals("")) {
                    lButton.setEnabled(false);
                } else {
                    lButton.setEnabled(true);
                }
                // you can call or do what you want with your EditText here
                //newNew. ...

            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });

        newName.setOnClickListener(this);
        lButton.setOnClickListener(this);
        pButton.setOnClickListener(this);
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub


        switch (v.getId()) {

            case R.id.editText:
                if (newName.getText().toString().equals("New Name...")) {
                    newName.setText("");
                }
                break;
            case R.id.learnButton:
                learning = true;
                dispatchTakePictureIntent();
                break;
            case R.id.predictButton:
                learning = false;
                dispatchTakePictureIntent();
                break;

            default:
                break;
        }
    }

    private File getFile() {
        // Create an image file name
        File storageDir = new File(getFilesDir(), "Pictures");

        if(!storageDir.exists())
            storageDir.mkdir();


        return new File(storageDir, "camera_image.jpg");
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if(getFile().exists())
            getFile().delete();

        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = getFile();

            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.openfaceapp.cr217.facepredict.pics",
                        photoFile);
                System.out.println(photoURI);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    private static String getDataUrlForImage(File file) throws IOException {

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        FileInputStream in = new FileInputStream(file);

        byte[] buffer = new byte[1024];
        int read;
        while((read = in.read(buffer)) != -1){
            out.write(buffer, 0, read);
        }
        out.close();
        in.close();


        StringBuilder builder = new StringBuilder();

        builder.append("data:image/jpeg;base64,");
        builder.append(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));

        return builder.toString();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == REQUEST_TAKE_PHOTO){
            if(resultCode == RESULT_OK){
                File imageFile = getFile();
                System.out.println("File capture success - attempting send");
                System.out.println(imageFile);

                try {
                    JSONObject dd = new JSONObject();
                    dd.put("type", "FRAME");
                    String dataURL = getDataUrlForImage(imageFile);
                    dd.put("dataURL", dataURL);
                    dd.put("identity", "testing");
                    queue.add(new JsonObjectRequest(Request.Method.POST, URL_SEND, dd, new Response.Listener<JSONObject>() {

                        @Override
                        public void onResponse(JSONObject response) {
                            System.out.println("GOT RESPONSE");
                            System.out.println(response);
                        }
                    }, new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {
                            System.out.println("GOT ERROR");
                            System.out.println(error);
                        }
                    }));
                } catch (IOException | JSONException e){
                    System.err.println("FAILED TO SEND");
                    e.printStackTrace();
                }

            } else {

            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }












    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Main Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.openfaceapp.cr217.facepredict/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Main Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.openfaceapp.cr217.facepredict/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }
}
